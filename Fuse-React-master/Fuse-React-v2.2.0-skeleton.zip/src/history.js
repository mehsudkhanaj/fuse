import * as history from 'history';

export default history.createBrowserHistory();
