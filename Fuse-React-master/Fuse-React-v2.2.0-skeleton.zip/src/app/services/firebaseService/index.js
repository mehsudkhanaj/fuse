import firebaseService from './firebaseService.js';

export default firebaseService;
